%Practica 2 Ander Pacheco
function error = calculoError(A, B, R)
    R_gorro=zeros(length(A),length(B));
    % Rellenamos la matriz por filas
    for i=1:length(A)
        % Rellenamos la matriz por columnas
        for j=1:length(B)
            R_gorro(i,j)=max(min(A(:,i),B(:,j)));
        end
    end
    error=sum(sum((R-R_gorro).^2));
    
    % Para mostrar la imagen que crean A y B
    % imshow(R_gorro);    
end